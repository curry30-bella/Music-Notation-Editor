# music-editor
- Introduction<br/>
Music editor is a gesture based music notation system.
Users can draw music elements by draging mouse to do some gestures.
The gestures represent a method of user input and show some pattern recognition AI techniques.<br/>
- Demo<br/>
The `TrainingDemo.mp4` shows gesture training process.<br/>
The `demo.mp4` shows how this music editor works.<br/>
- Run project<br/>
You can open the music-editor folder using your IDE and run main.java to run the application.<br/>
- Notice<br/>
Font 'Sinfonia' is used for music natation. Strange shape may show on Windows since lack of font.<br/>
